const startAction = {
    type: "rotate",
    payload: true
};
export default startAction;