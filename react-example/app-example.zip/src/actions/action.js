import startAction  from "./startAction";
import stopAction  from "./stopAction";

const rootAction = {
    start: startAction,
    stop: stopAction
};
export default rootAction;