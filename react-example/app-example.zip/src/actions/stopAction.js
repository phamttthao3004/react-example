const stopAction = {
    type: "rotate",
    payload: false
};
export default stopAction;