import React from "react";

class Topic extends React.Component{
  render(){
    return <h3>Requested Param: </h3>;
  }
}

export default Topic;